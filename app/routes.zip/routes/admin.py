from flask import Blueprint, render_template, request, redirect, url_for
from app.models import User, Drone
from app import db
bp = Blueprint('admin', __name__)

@bp.route('/')
def dashboard():
    return render_template('admin.html')

@bp.route('/add_user', methods=['POST'])
def add_user():
    username = request.form['username']
    password = request.form['password']
    new_user = User(username=username, password=password)
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('admin.dashboard'))

@bp.route('/manage_drone')
def manage_drone():
    drones = Drone.query.all()
    return render_template('manage_drone.html', drones=drones)
